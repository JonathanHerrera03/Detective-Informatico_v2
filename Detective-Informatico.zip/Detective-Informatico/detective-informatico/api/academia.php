<?php
declare(strict_types=1);
require __DIR__.'/bootstrap.php';
require __DIR__.'/retos.php';

function rate_limit(string $key, int $limit, int $seconds): void {
    $key=hash('sha256',$key); $now=time();
    query('INSERT INTO intentos_acceso (clave,cantidad,vence) VALUES (?,1,?) ON DUPLICATE KEY UPDATE cantidad=IF(vence<?,1,cantidad+1),vence=IF(vence<?,VALUES(vence),vence)',[$key,$now+$seconds,$now,$now]);
    if ((int)query('SELECT cantidad FROM intentos_acceso WHERE clave=?',[$key])->fetchColumn()>$limit) fail('Demasiados intentos. Espera unos minutos antes de volver a intentarlo.',429);
}
function read_state(): void {
    $u=current_user(); $staff=$u && $u['rol']!=='estudiante'; $users=[]; $results=[]; $assign=[]; $activities=[]; $games=[];
    if ($u) {
        if ($staff) $users=array_map('public_user',query('SELECT * FROM usuarios ORDER BY creado,id')->fetchAll());
        $sql='SELECT id,usuario_id AS user_id,modulo_id AS module_id,tipo AS kind,elemento_id AS item_id,correctas AS score,total,puntos AS points,creado AS created FROM resultados';
        $results=query($sql.($staff?'':' WHERE usuario_id=?').' ORDER BY creado DESC,id DESC LIMIT 5000',$staff?[]:[$u['id']])->fetchAll();
        foreach ($results as &$r) foreach (['module_id','score','total','points'] as $k) $r[$k]=(int)$r[$k]; unset($r);
        $assign=query('SELECT id,estudiante_id AS student_id,modulo_id AS module_id,autor_id AS author,creado AS created FROM asignaciones'.($staff?'':' WHERE estudiante_id=?').' ORDER BY creado DESC',$staff?[]:[$u['id']])->fetchAll();
        foreach ($assign as &$a) $a['module_id']=(int)$a['module_id']; unset($a);
        foreach (query('SELECT modulo_id,elementos,destinos FROM actividades ORDER BY modulo_id')->fetchAll() as $a) {
            $activities[(int)$a['modulo_id']]=['items'=>json_decode($a['elementos'],true,512,JSON_THROW_ON_ERROR),'targets'=>json_decode($a['destinos'],true,512,JSON_THROW_ON_ERROR),'extras'=>public_extra_activities((int)$a['modulo_id'])];
        }
        $games=json_decode(file_get_contents(__DIR__.'/juegos.json'),true,512,JSON_THROW_ON_ERROR);
    }
    $lab=query("SELECT valor FROM configuracion WHERE clave='lab'")->fetchColumn();
    $ready=(int)query("SELECT COUNT(*) FROM usuarios WHERE rol='administrador' AND activo=1 AND contrasena_hash IS NOT NULL")->fetchColumn()>0;
    reply(['user'=>$u?public_user($u):null,'identity'=>$u?['name'=>$u['nombre'],'email'=>$u['correo']]:null,'csrf'=>$_SESSION['csrf'],'setupRequired'=>!$ready,'attempts'=>$results,'users'=>$users,'assignments'=>$assign,'lab'=>$u?($lab?:''):'','activities'=>(object)$activities,'games'=>(object)$games,'catalogue'=>$u?catalogue((bool)$staff):['modules'=>[],'questions'=>[],'cases'=>[]]]);
}
function upsert_resource(array $b, array $user): void {
    if (!in_array($user['rol'],['administrador','docente'],true)) fail('Solo el personal autorizado gestiona contenidos.',403);
    $type=$b['type']??''; $mod=$b['module']??null; $d=$b['data']??null;
    if (!in_array($type,['module','question','case'],true)||($type==='module'&&$user['rol']!=='administrador')) fail('Sin permiso para este contenido.',403);
    if (!is_int($mod)||$mod<1||$mod>6||!is_array($d)) fail('Contenido o módulo no válido.');
    $id=(string)($b['id']??uuid()); if (strlen($id)>100) fail('Identificador demasiado largo.');
    $json=fn($v)=>json_encode($v,JSON_UNESCAPED_UNICODE|JSON_THROW_ON_ERROR);
    if ($type==='module') {
        $title=trim((string)($d['title']??'')); $lessons=$d['lessons']??[];
        if ($title===''||mb_strlen($title)>100||!is_array($lessons)||count($lessons)<1||count($lessons)>100) fail('Completa el título y las lecciones.');
        foreach ($lessons as $l) if (!is_array($l)||!is_string($l['title']??null)||!is_string($l['text']??null)||!is_string($l['example']??null)||trim($l['title'])===''||trim($l['text'])==='') fail('Cada lección necesita título, contenido y ejemplo.');
        query('UPDATE modulos SET titulo=?,subtitulo=?,lecciones=? WHERE id=?',[$title,mb_substr((string)($d['subtitle']??''),0,150),$json($lessons),$mod]); reply(['ok'=>true]);
    }
    $table=$type==='question'?'preguntas':'casos'; $other=$type==='question'?'casos':'preguntas';
    if (query("SELECT id FROM $other WHERE id=?",[$id])->fetch()) fail('Este identificador pertenece a otro tipo de contenido.');
    if (!empty($d['deleted'])) { query("DELETE FROM $table WHERE id=?",[$id]); reply(['ok'=>true]); }
    $options=$d['options']??[]; $answer=$d['answer']??null; $explanation=trim((string)($d['explanation']??''));
    if (!is_array($options)||count($options)!==4||!is_int($answer)||$answer<0||$answer>3||$explanation==='') fail('Incluye cuatro opciones, respuesta correcta y retroalimentación.');
    foreach ($options as $v) if (!is_string($v)||trim($v)===''||mb_strlen($v)>2000) fail('Completa las cuatro opciones.');
    if ($type==='question') {
        $prompt=trim((string)($d['prompt']??'')); if ($prompt==='') fail('Escribe la pregunta.');
        query('INSERT INTO preguntas (id,modulo_id,enunciado,opciones,respuesta,explicacion,autor_id) VALUES (?,?,?,?,?,?,?) ON DUPLICATE KEY UPDATE modulo_id=VALUES(modulo_id),enunciado=VALUES(enunciado),opciones=VALUES(opciones),respuesta=VALUES(respuesta),explicacion=VALUES(explicacion),autor_id=VALUES(autor_id)',[$id,$mod,$prompt,$json($options),$answer,$explanation,$user['id']]);
    } else {
        $title=trim((string)($d['title']??'')); $story=trim((string)($d['story']??'')); $clues=$d['clues']??[];
        if ($title===''||mb_strlen($title)>200||$story===''||!is_array($clues)||!count($clues)) fail('Completa el título, escenario y pistas.');
        foreach ($clues as $v) if (!is_string($v)||trim($v)==='') fail('Completa cada pista.');
        query('INSERT INTO casos (id,modulo_id,titulo,escenario,categoria,pistas,opciones,respuesta,explicacion,autor_id) VALUES (?,?,?,?,?,?,?,?,?,?) ON DUPLICATE KEY UPDATE modulo_id=VALUES(modulo_id),titulo=VALUES(titulo),escenario=VALUES(escenario),categoria=VALUES(categoria),pistas=VALUES(pistas),opciones=VALUES(opciones),respuesta=VALUES(respuesta),explicacion=VALUES(explicacion),autor_id=VALUES(autor_id)',[$id,$mod,$title,$story,mb_substr((string)($d['category']??'Diagnóstico'),0,80),$json($clues),$json($options),$answer,$explanation,$user['id']]);
    }
    reply(['ok'=>true]);
}

try {
    if ($_SERVER['REQUEST_METHOD']==='GET') read_state();
    if ($_SERVER['REQUEST_METHOD']!=='POST') fail('Método no permitido.',405);
    if ((int)($_SERVER['CONTENT_LENGTH']??0)>200000) fail('Solicitud demasiado extensa.',413);
    csrf_check();
    $b=json_decode(file_get_contents('php://input'),true,512,JSON_THROW_ON_ERROR);
    if (!is_array($b)) fail('Solicitud no válida.');
    $action=$b['action']??'';
    if ($action==='logout') { $_SESSION=[]; session_regenerate_id(true); $_SESSION['csrf']=bin2hex(random_bytes(32)); reply(['ok'=>true]); }
    if ($action==='setup') {
        if (!in_array($_SERVER['REMOTE_ADDR']??'', ['127.0.0.1','::1'], true)) fail('La primera cuenta debe configurarse desde localhost en el computador del servidor.',403);
        $name=clean_name($b['name']??null); $email=clean_email($b['email']??null); $password=valid_password($b['password']??null); $hash=hash_password($password);
        db()->beginTransaction(); query("SELECT valor FROM configuracion WHERE clave='bloqueo_administradores' FOR UPDATE")->fetch();
        if ((int)query("SELECT COUNT(*) FROM usuarios WHERE rol='administrador' AND activo=1 AND contrasena_hash IS NOT NULL")->fetchColumn()>0) { db()->rollBack(); fail('La instalación ya está completada. Inicia sesión.'); }
        $pending=query("SELECT * FROM usuarios WHERE rol='administrador' AND contrasena_hash IS NULL ORDER BY creado,id LIMIT 1 FOR UPDATE")->fetch();
        $id=$pending?$pending['id']:uuid();
        if ($pending) query('UPDATE usuarios SET nombre=?,correo=?,contrasena_hash=?,activo=1,version_sesion=version_sesion+1 WHERE id=?',[$name,$email,$hash,$id]);
        else query("INSERT INTO usuarios (id,nombre,correo,contrasena_hash,rol,activo,creado) VALUES (?,?,?,?,'administrador',1,?)",[$id,$name,$email,$hash,now_iso()]);
        db()->commit(); sign_in(query('SELECT * FROM usuarios WHERE id=?',[$id])->fetch()); reply(['ok'=>true]);
    }
    if ($action==='register') {
        if (!(int)query("SELECT COUNT(*) FROM usuarios WHERE rol='administrador' AND activo=1 AND contrasena_hash IS NOT NULL")->fetchColumn()) fail('Primero completa la instalación desde instalar.php.',503);
        $role=$b['role']??'estudiante';
        if ($role==='administrador') fail('Solo un administrador puede crear cuentas administradoras.',403);
        if (!in_array($role,['estudiante','docente'],true)) fail('Selecciona Estudiante o Profesor para registrarte.');
        rate_limit('registro:'.($_SERVER['REMOTE_ADDR']??''),20,3600);
        $name=clean_name($b['name']??null); $email=clean_email($b['email']??null); $password=valid_password($b['password']??null);
        if (query('SELECT id FROM usuarios WHERE correo=?',[$email])->fetch()) fail('Ya existe una cuenta con ese correo. Inicia sesión o solicita ayuda al administrador.',409);
        $id=uuid(); query("INSERT INTO usuarios (id,nombre,correo,contrasena_hash,rol,activo,creado) VALUES (?,?,?,?,?,1,?)",[$id,$name,$email,hash_password($password),$role,now_iso()]);
        sign_in(query('SELECT * FROM usuarios WHERE id=?',[$id])->fetch()); reply(['ok'=>true]);
    }
    if ($action==='login') {
        $email=clean_email($b['email']??null); $password=is_string($b['password']??null)?$b['password']:'';
        rate_limit('login:'.$email.':'.($_SERVER['REMOTE_ADDR']??''),10,900);
        $u=query('SELECT * FROM usuarios WHERE correo=?',[$email])->fetch();
        if (!$u || !$u['contrasena_hash']) { hash_password('dummy-login-timing'); fail('Correo o contraseña incorrectos, o cuenta desactivada.',401); }
        if (strlen($password)>72||!password_verify($password,$u['contrasena_hash'])||!$u['activo']) fail('Correo o contraseña incorrectos, o cuenta desactivada.',401);
        if (password_needs_rehash($u['contrasena_hash'],PASSWORD_BCRYPT,['cost'=>12])) query('UPDATE usuarios SET contrasena_hash=? WHERE id=?',[hash_password($password),$u['id']]);
        query('DELETE FROM intentos_acceso WHERE clave=?',[hash('sha256','login:'.$email.':'.($_SERVER['REMOTE_ADDR']??''))]); sign_in($u); reply(['ok'=>true]);
    }
    $u=signed_user(); $staff=in_array($u['rol'],['administrador','docente'],true); $admin=$u['rol']==='administrador';
    if ($action==='createAdmin') {
        if (!$admin) fail('Solo un administrador puede crear cuentas administradoras.',403);
        $name=clean_name($b['name']??null); $email=clean_email($b['email']??null); $hash=hash_password(valid_password($b['password']??null));
        admin_lock();
        if (query('SELECT id FROM usuarios WHERE correo=?',[$email])->fetch()) { db()->rollBack(); fail('Ya existe una cuenta con ese correo. Puedes editarla desde Usuarios.',409); }
        $id=uuid(); query("INSERT INTO usuarios (id,nombre,correo,contrasena_hash,rol,activo,creado) VALUES (?,?,?,?,'administrador',1,?)",[$id,$name,$email,$hash,now_iso()]);
        db()->commit(); reply(['ok'=>true,'id'=>$id]);
    }
    if ($action==='attempt') {
        $mod=$b['module']??null; $kind=$b['kind']??'';
        if (!is_int($mod)||$mod<1||$mod>6) fail('Módulo no válido.');
        if (!in_array($kind,['quiz','case','activity'],true)) fail('Actividad desconocida.');
        if ($mod===6 && (int)query("SELECT COUNT(DISTINCT modulo_id) FROM resultados WHERE usuario_id=? AND tipo='quiz' AND modulo_id<6 AND correctas*100>=total*70",[$u['id']])->fetchColumn()<5) fail('Aprueba las cinco evaluaciones anteriores para desbloquear la misión final.');
        $score=0; $total=0; $feedback=[]; $item=$kind.'-'.$mod;
        if ($kind==='quiz') {
            $cat=catalogue();
            $qs=array_values(array_filter($cat['questions'],fn($q)=>$q['module']===$mod)); if (!$qs) fail('Esta evaluación no tiene preguntas.');
            foreach ($qs as $q) { $answer=$b['answers'][$q['id']]??null; if (!is_int($answer)||$answer<0||$answer>3) fail('Responde todas las preguntas.'); $correct=$answer===$q['answer']; $score+=(int)$correct; $feedback[]=['id'=>$q['id'],'correct'=>$correct,'answer'=>$q['answer'],'explanation'=>$q['explanation']]; } $total=count($qs);
        } elseif ($kind==='case') {
            $cat=catalogue();
            $found=array_values(array_filter($cat['cases'],fn($c)=>$c['id']===($b['itemId']??'')&&$c['module']===$mod)); if (!$found) fail('Caso no encontrado.',404); $c=$found[0]; $answer=$b['answer']??null;
            if (!is_int($answer)||$answer<0||$answer>3) fail('Selecciona una solución.'); $score=(int)($answer===$c['answer']); $total=1; $item=$c['id']; $feedback[]=['id'=>$c['id'],'correct'=>(bool)$score,'answer'=>$c['answer'],'explanation'=>$c['explanation']];
        } elseif ($kind==='activity') {
            $requested=$b['itemId']??$item;
            if ($requested===$item) {
                $a=activity($mod); $order=$b['order']??[]; $total=count($a['correct']);
                if (!is_array($order)||count($order)!==$total) fail('Completa todas las relaciones.');
                $seen=[];
                foreach (array_values($order) as $i=>$n) {
                    if (!is_int($n)||$n<0||$n>=$total||isset($seen[$n])) fail('Selecciona una opción distinta en cada relación.');
                    $seen[$n]=true; $correct=$n===$a['correct'][$i]; $score+=(int)$correct;
                    $feedback[]=['id'=>(string)$i,'correct'=>$correct,'answer'=>$a['correct'][$i],'explanation'=>$a['explanation']];
                }
            } else {
                $found=array_values(array_filter(extra_activities($mod),fn($a)=>$a['id']===$requested));
                if (!$found) fail('Actividad no encontrada en este módulo.',404);
                $a=$found[0]; $item=$a['id']; $total=count($a['questions']); $answers=$b['answers']??[];
                if (!is_array($answers)) fail('Responde todas las decisiones del reto.');
                foreach ($a['questions'] as $i=>$q) {
                    $answer=$answers[$i]??null;
                    if (!is_int($answer)||$answer<0||$answer>=count($q['options'])) fail('Responde todas las decisiones del reto.');
                    $correct=$answer===$q['answer']; $score+=(int)$correct;
                    $feedback[]=['id'=>(string)$i,'correct'=>$correct,'answer'=>$q['answer'],'explanation'=>$q['explanation']];
                }
            }
        } else fail('Actividad desconocida.');
        $points=(int)round($score/$total*($kind==='quiz'?150:($kind==='case'?100:80)));
        query('INSERT INTO resultados (id,usuario_id,modulo_id,tipo,elemento_id,correctas,total,puntos,creado) VALUES (?,?,?,?,?,?,?,?,?)',[uuid(),$u['id'],$mod,$kind,$item,$score,$total,$points,now_iso()]); reply(['ok'=>true,'itemId'=>$item,'score'=>$score,'total'=>$total,'points'=>$points,'feedback'=>$feedback]);
    }
    if ($action==='profile') { $name=clean_name($b['name']??null); query('UPDATE usuarios SET nombre=? WHERE id=?',[$name,$u['id']]); reply(['ok'=>true]); }
    if ($action==='password') {
        if (!is_string($b['currentPassword']??null)||!password_verify($b['currentPassword'],$u['contrasena_hash'])) fail('Tu contraseña actual no es correcta.');
        $password=valid_password($b['password']??null); query('UPDATE usuarios SET contrasena_hash=?,version_sesion=version_sesion+1 WHERE id=?',[hash_password($password),$u['id']]); sign_in(query('SELECT * FROM usuarios WHERE id=?',[$u['id']])->fetch()); reply(['ok'=>true]);
    }
    if ($action==='user'||$action==='deleteUser') {
        if (!$admin) fail('Solo el administrador gestiona usuarios.',403);
        $id=(string)($b['id']??''); if ($action==='deleteUser'&&$id===$u['id']) fail('No puedes eliminar la cuenta que estás utilizando.');
        $newHash=null; if ($action==='user'&&!empty($b['password'])) $newHash=hash_password(valid_password($b['password']));
        admin_lock(); $target=query('SELECT * FROM usuarios WHERE id=? FOR UPDATE',[$id])->fetch(); if (!$target) { db()->rollBack(); fail('Usuario no encontrado.',404); }
        if ($action==='deleteUser') { preserve_admin($target,'estudiante',0); query('DELETE FROM usuarios WHERE id=?',[$id]); db()->commit(); reply(['ok'=>true]); }
        $role=$b['role']??''; $active=$b['active']??null;
        if (!in_array($role,['estudiante','docente','administrador'],true)||!in_array($active,[0,1,false,true],true)) { db()->rollBack(); fail('Rol o estado no válido.'); }
        $active=(int)$active; preserve_admin($target,$role,$active);
        $name=clean_name($b['name']??$target['nombre']); $email=clean_email($b['email']??$target['correo']);
        query('UPDATE usuarios SET nombre=?,correo=?,rol=?,activo=?'.($newHash?',contrasena_hash=?,version_sesion=version_sesion+1':'').' WHERE id=?',array_merge([$name,$email,$role,$active],$newHash?[$newHash]:[],[$id]));
        db()->commit(); if ($id===$u['id']&&$newHash&&$active) sign_in(query('SELECT * FROM usuarios WHERE id=?',[$id])->fetch()); reply(['ok'=>true,'selfUpdated'=>$id===$u['id']]);
    }
    if ($action==='resource') { if (strlen(json_encode($b))>150000) fail('Contenido demasiado extenso.'); upsert_resource($b,$u); }
    if ($action==='assign') {
        if (!$staff) fail('Solo docentes y administradores asignan actividades.',403); $mod=$b['module']??null;
        if (!is_int($mod)||$mod<1||$mod>6||!query("SELECT id FROM usuarios WHERE id=? AND rol='estudiante' AND activo=1",[(string)($b['studentId']??'')])->fetch()) fail('Selecciona un estudiante activo y un módulo.');
        query('INSERT IGNORE INTO asignaciones (id,estudiante_id,modulo_id,autor_id,creado) VALUES (?,?,?,?,?)',[uuid(),$b['studentId'],$mod,$u['id'],now_iso()]); reply(['ok'=>true]);
    }
    if ($action==='settings') {
        if (!$admin) fail('Solo el administrador modifica la configuración.',403); $title=trim((string)($b['title']??'')); if ($title===''||mb_strlen($title)>80) fail('Escribe un nombre de laboratorio de hasta 80 caracteres.');
        query("INSERT INTO configuracion (clave,valor) VALUES ('lab',?) ON DUPLICATE KEY UPDATE valor=VALUES(valor)",[$title]); reply(['ok'=>true]);
    }
    fail('Operación desconocida.');
} catch (PDOException $e) {
    try { if (db()->inTransaction()) db()->rollBack(); } catch (Throwable $ignored) {}
    error_log('Detective Informático: '.$e->getMessage());
    if ($e->getCode()==='23000') fail('Ese correo o identificador ya está registrado. Revisa los datos.',409);
    fail('No se pudo acceder a la base de datos. Inicia MySQL en XAMPP, importa el archivo SQL y revisa config/config.php.',503);
} catch (JsonException $e) { fail('La solicitud o los contenidos no tienen un formato JSON válido.'); }
catch (Throwable $e) { error_log('Detective Informático: '.$e->getMessage()); fail('No pudimos completar la operación. Revisa el registro de PHP.',500); }
