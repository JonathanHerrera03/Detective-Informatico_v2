<?php
declare(strict_types=1);

function extra_activities(int $module): array {
    static $modules;
    if ($modules === null) $modules = [
        1 => [
            ['Diagnóstico en el taller','Una compañera trae su portátil porque se vuelve lento al abrir varias aplicaciones. Identifica las piezas que intervienen.',[
                ['¿Qué componente guarda temporalmente los datos de las aplicaciones abiertas?',['Disco externo','Memoria RAM','Teclado'],1,'La RAM mantiene disponibles los datos que están usando las aplicaciones.'],
                ['¿Qué pieza ejecuta las instrucciones de los programas?',['Procesador','Pantalla','Unidad SSD'],0,'El procesador interpreta y ejecuta instrucciones.'],
                ['¿Dónde queda un archivo guardado tras apagar el equipo?',['En la RAM','En el procesador','En la unidad de almacenamiento'],2,'El almacenamiento conserva los archivos sin energía.'],
            ]],
            ['Del periférico a la aplicación','Prepara un equipo para grabar y editar una entrevista escolar.',[
                ['¿Qué dispositivo convierte la voz en datos de entrada?',['Altavoz','Monitor','Micrófono'],2,'El micrófono captura sonido para que el equipo pueda procesarlo.'],
                ['¿Qué tipo de software administra el micrófono y la memoria?',['Sistema operativo','Presentación','Editor de audio'],0,'El sistema operativo gestiona los recursos y dispositivos del equipo.'],
                ['¿Cuál de estos elementos es software de aplicación?',['Cable USB','Editor de audio','Tarjeta de sonido'],1,'El editor es un programa que realiza una tarea para el usuario.'],
            ]],
        ],
        2 => [
            ['El aula sin conexión','Solo una computadora del aula no puede abrir el portal. Los demás equipos sí pueden.',[
                ['¿Qué conviene revisar primero?',['La conexión de esa computadora','El proveedor de todo el país','Las contraseñas de los demás'],0,'Comienza por el equipo afectado: revisa el cable, Wi-Fi o adaptador.'],
                ['El portal abre desde otros equipos. ¿Qué indica esa pista?',['El portal dejó de existir','El problema puede estar en el equipo o su conexión','Todos los equipos tienen la misma falla'],1,'Comparar el alcance ayuda a separar una falla local de una general.'],
                ['Tras conectar el cable, ¿cómo confirmas la solución?',['Cambias el teclado','Cierras la sesión sin probar','Abres el portal en la computadora afectada'],2,'Repite la acción que fallaba para verificar el resultado.'],
            ]],
            ['Rastrea la ruta de los datos','Un equipo conectado al Wi-Fi necesita consultar una página web.',[
                ['¿Qué equipo conecta la red del aula con otras redes?',['Impresora','Router','Monitor'],1,'El router dirige paquetes entre redes.'],
                ['¿Qué dato identifica a un equipo dentro de la red?',['El tamaño de la pantalla','La contraseña de una aplicación','La dirección IP'],2,'Una dirección IP identifica un destino en una red.'],
                ['¿Qué servicio traduce un nombre de sitio a una dirección IP?',['DNS','El teclado','El almacenamiento'],0,'El DNS permite resolver nombres de dominio en direcciones IP.'],
            ]],
        ],
        3 => [
            ['La beca demasiado urgente','Recibes un mensaje inesperado que promete una beca si confirmas tu contraseña en diez minutos.',[
                ['¿Cuál es la primera señal de alerta?',['El uso de tildes','La urgencia junto con la solicitud de contraseña','La hora de recepción por sí sola'],1,'La presión y la petición de datos privados son señales de posible suplantación.'],
                ['¿Cómo verificas que la beca sea real?',['Escribes tu clave en el enlace','Reenvías el mensaje a todos','Consultas el canal oficial por separado'],2,'Usa un canal oficial conocido, sin abrir el enlace del mensaje.'],
                ['¿Qué haces si confirmas que el mensaje es falso?',['Lo reportas y no compartes tus datos','Respondes con tu código de acceso','Descargas el archivo adjunto'],0,'Reportar el mensaje protege a otras personas y evita exponer datos.'],
            ]],
            ['Escudo para tu cuenta','Vas a proteger tu cuenta escolar después de usar un equipo compartido.',[
                ['¿Qué opción fortalece mejor tu acceso?',['Una contraseña corta repetida','Una contraseña única y verificación en dos pasos','El nombre del colegio como contraseña'],1,'Una contraseña única y un segundo factor reducen el riesgo de acceso indebido.'],
                ['Al terminar en el equipo compartido, ¿qué haces?',['Cierras sesión','Solo minimizas la ventana','Guardas la contraseña en el navegador'],0,'Cerrar sesión evita que otra persona use tu cuenta abierta.'],
                ['Alguien pide el código temporal de acceso. ¿Qué haces?',['Lo envías si usa un logo oficial','Lo publicas en el grupo','No lo compartes y verificas la solicitud'],2,'Los códigos de acceso son privados, incluso ante mensajes que parezcan oficiales.'],
            ]],
        ],
        4 => [
            ['El robot que reparte carpetas','Diseña instrucciones para que un robot reparta una carpeta a cada estudiante.',[
                ['¿Cuál es un paso preciso para un algoritmo?',['Entrega una carpeta a la siguiente persona de la lista','Hazlo bien','Resuelve todo rápido'],0,'Un algoritmo usa instrucciones claras y ejecutables.'],
                ['¿Cómo expresas que la entrega se repite?',['Repetir mientras haya personas pendientes','Borrar la lista al empezar','Entregar solo a la primera persona'],0,'Un bucle repite una instrucción mientras se cumpla su condición.'],
                ['Si no quedan carpetas, ¿qué debe hacer el robot?',['Seguir como si hubiera','Detenerse y avisar que faltan carpetas','Saltar a una persona al azar'],1,'Una condición permite decidir qué hacer ante un caso diferente.'],
            ]],
            ['Encuentra el error del algoritmo','Un programa debe sumar los números del 1 al 3. Empieza con total igual a 0, pero solo suma 1 y 2.',[
                ['¿Cuál debería ser el resultado final?',['3','6','9'],1,'La suma de 1, 2 y 3 es 6.'],
                ['¿Qué cambio corrige el error?',['Incluir el 3 en el recorrido','Empezar con total igual a 10','Eliminar la suma del 1'],0,'El recorrido debe incluir el límite final para sumar los tres valores.'],
                ['¿Cómo confirmas que el cambio funciona?',['Cambias el nombre del programa','Cierras el programa sin probar','Ejecutas la prueba y comparas el resultado con 6'],2,'Comparar con un resultado esperado permite verificar la corrección.'],
            ]],
        ],
        5 => [
            ['La pantalla que no responde','Una computadora enciende, pero el monitor muestra «sin señal».',[
                ['¿Cuál es el síntoma observado?',['Se dañó la tarjeta gráfica','El monitor muestra «sin señal»','El sistema necesita reinstalarse'],1,'El síntoma es lo que observas; las posibles causas aún son hipótesis.'],
                ['¿Cuál es una primera prueba sencilla?',['Revisar el cable y la entrada seleccionada','Comprar otra computadora','Borrar todos los archivos'],0,'Conviene empezar por conexiones y ajustes reversibles.'],
                ['Después de corregir la entrada, ¿qué evidencia confirma la solución?',['El ratón se mueve','El cable es nuevo','El monitor vuelve a mostrar la imagen'],2,'Verifica que el síntoma haya desaparecido en el equipo afectado.'],
            ]],
            ['Un cambio a la vez','Una impresora no responde. Tienes varias hipótesis y debes dejar un registro útil.',[
                ['¿Qué estrategia facilita saber qué resolvió el problema?',['Cambiar todas las opciones a la vez','Probar una hipótesis y verificar antes de pasar a la siguiente','Instalar software sin anotar nada'],1,'Un cambio a la vez permite relacionar el resultado con la prueba.'],
                ['¿Qué dato es más útil en tu registro?',['Síntoma, prueba y resultado observado','Solo el nombre de quien reportó','Una conclusión sin evidencias'],0,'Un registro útil explica qué falló, qué se probó y qué ocurrió.'],
                ['Si la primera prueba no cambia el síntoma, ¿qué haces?',['La das por exitosa','Dejas de revisar','Anotas el resultado y pruebas otra hipótesis'],2,'Una prueba negativa también aporta información al diagnóstico.'],
            ]],
        ],
        6 => [
            ['Incidente en el laboratorio','Dos equipos pierden acceso al portal después de que llega un correo con un archivo inesperado.',[
                ['¿Qué haces con el archivo mientras investigas?',['Lo abres para ver qué contiene','Evitas abrirlo y lo reportas','Lo copias en todos los equipos'],1,'No ejecutes archivos inesperados mientras verificas su origen.'],
                ['¿Qué ayuda a delimitar el problema de acceso?',['Revisar si el portal abre desde un equipo sin fallas','Apagar toda la red sin comprobar nada','Cambiar todas las contraseñas como primera prueba'],0,'Comparar equipos afectados y no afectados ayuda a localizar la falla.'],
                ['Al recuperar el acceso, ¿cómo cierras el incidente?',['Solo borras el aviso','Declaras que nunca hubo un problema','Verificas el acceso, registras las pruebas y comunicas el resultado'],2,'Un cierre completo incluye verificación, registro y comunicación.'],
            ]],
            ['Entrega de evidencias','Tu equipo prepara un informe sobre una falla de red y una alerta de seguridad.',[
                ['¿Qué afirmación debe ir como observación verificable?',['El cable estaba desconectado al revisar el puerto','Seguro que alguien lo hizo a propósito','Todos los correos son peligrosos'],0,'Las evidencias describen hechos observados, no suposiciones.'],
                ['¿Qué detalle demuestra que la solución funcionó?',['Que el reporte tiene un logo','Que se volvió a abrir el portal en los equipos afectados','Que nadie volvió a hablar del caso'],1,'Repetir con éxito la acción original demuestra el resultado.'],
                ['¿Qué debes evitar en el informe compartido?',['La fecha de la prueba','La descripción de la solución','Contraseñas o códigos privados'],2,'Los informes deben compartir evidencias sin revelar credenciales.'],
            ]],
        ],
    ];
    $result=[];
    foreach ($modules[$module]??[] as $i=>[$title,$task,$questions]) {
        $result[]=['id'=>'activity-'.$module.'-'.($i+2),'title'=>$title,'task'=>$task,'questions'=>array_map(fn($q)=>['prompt'=>$q[0],'options'=>$q[1],'answer'=>$q[2],'explanation'=>$q[3]],$questions)];
    }
    return $result;
}

function public_extra_activities(int $module): array {
    return array_map(function($activity){
        $activity['questions']=array_map(fn($q)=>['prompt'=>$q['prompt'],'options'=>$q['options']],$activity['questions']);
        return $activity;
    },extra_activities($module));
}
