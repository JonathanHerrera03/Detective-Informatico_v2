<?php
declare(strict_types=1);

$config = require __DIR__ . '/../config/config.php';
date_default_timezone_set($config['timezone']);
ini_set('display_errors', '0');
ini_set('session.use_strict_mode', '1');
ini_set('session.use_only_cookies', '1');
session_name('detective_informatico');
session_set_cookie_params([
    'lifetime' => 0, 'path' => '/',
    'secure' => !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off',
    'httponly' => true, 'samesite' => 'Lax',
]);
session_start();
if (!isset($_SESSION['csrf'])) $_SESSION['csrf'] = bin2hex(random_bytes(32));
header('Cache-Control: no-store');
header('X-Content-Type-Options: nosniff');

function db(): PDO {
    static $pdo;
    global $config;
    if (!$pdo) {
        $pdo = new PDO('mysql:host='.$config['host'].';port='.$config['port'].';dbname='.$config['database'].';charset=utf8mb4', $config['username'], $config['password'], [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC, PDO::ATTR_EMULATE_PREPARES => false]);
        $pdo->exec("SET time_zone = '+00:00'");
    }
    return $pdo;
}
function query(string $sql, array $params = []): PDOStatement {
    $s = db()->prepare($sql); $s->execute($params); return $s;
}
function reply(array $data, int $status = 200): void {
    http_response_code($status); header('Content-Type: application/json; charset=utf-8');
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR); exit;
}
function fail(string $message, int $status = 400): void { reply(['error' => $message], $status); }
function uuid(): string {
    $b = random_bytes(16); $b[6] = chr((ord($b[6]) & 15) | 64); $b[8] = chr((ord($b[8]) & 63) | 128);
    $h = bin2hex($b); return substr($h,0,8).'-'.substr($h,8,4).'-'.substr($h,12,4).'-'.substr($h,16,4).'-'.substr($h,20);
}
function now_iso(): string { return gmdate('Y-m-d\TH:i:s\Z'); }
function public_user(array $u): array {
    return ['id' => $u['id'], 'name' => $u['nombre'], 'email' => $u['correo'], 'role' => $u['rol'], 'active' => (int)$u['activo'], 'created' => $u['creado']];
}
function current_user(): ?array {
    global $config;
    if (empty($_SESSION['uid'])) return null;
    if (time() - (int)($_SESSION['last_seen'] ?? 0) > $config['session_minutes'] * 60) { unset($_SESSION['uid']); return null; }
    $u = query('SELECT * FROM usuarios WHERE id = ?', [$_SESSION['uid']])->fetch();
    if (!$u || !$u['activo'] || (int)$u['version_sesion'] !== (int)($_SESSION['version'] ?? -1)) { unset($_SESSION['uid']); return null; }
    $_SESSION['last_seen'] = time(); return $u;
}
function signed_user(): array { $u = current_user(); if (!$u) fail('Inicia sesión para continuar. Tu sesión puede haber caducado.', 401); return $u; }
function sign_in(array $u): void {
    session_regenerate_id(true);
    $_SESSION['uid'] = $u['id']; $_SESSION['version'] = (int)$u['version_sesion']; $_SESSION['last_seen'] = time(); $_SESSION['csrf'] = bin2hex(random_bytes(32));
}
function csrf_check(): void {
    $token = $_SERVER['HTTP_X_CSRF_TOKEN'] ?? ($_POST['csrf'] ?? '');
    if (!is_string($token) || !hash_equals($_SESSION['csrf'], $token)) fail('La sesión cambió. Recarga la página e inténtalo de nuevo.', 403);
    $origin = $_SERVER['HTTP_ORIGIN'] ?? '';
    if ($origin !== '') {
        $o = parse_url($origin); $authority = ($o['host'] ?? '').(isset($o['port']) ? ':'.$o['port'] : '');
        if (strtolower($authority) !== strtolower($_SERVER['HTTP_HOST'] ?? '')) fail('Origen no permitido.', 403);
    }
}
function clean_name($v): string {
    if (!is_string($v)) fail('Nombre no válido.'); $v = trim($v);
    if (mb_strlen($v) < 2 || mb_strlen($v) > 80) fail('El nombre debe tener entre 2 y 80 caracteres.'); return $v;
}
function clean_email($v): string {
    if (!is_string($v)) fail('Correo no válido.'); $v = mb_strtolower(trim($v));
    if (strlen($v) > 254 || !filter_var($v, FILTER_VALIDATE_EMAIL)) fail('Escribe un correo electrónico válido.'); return $v;
}
function valid_password($v): string {
    if (!is_string($v) || strlen($v) < 10 || strlen($v) > 72 || strpos($v, "\0") !== false) fail('La contraseña debe tener entre 10 y 72 bytes. Puedes usar una frase larga.'); return $v;
}
function hash_password(string $password): string { return password_hash($password, PASSWORD_BCRYPT, ['cost' => 12]); }
function admin_lock(): void {
    db()->beginTransaction(); query("SELECT valor FROM configuracion WHERE clave='bloqueo_administradores' FOR UPDATE")->fetch();
    $u = current_user();
    if (!$u || $u['rol'] !== 'administrador') { db()->rollBack(); fail('Solo el administrador gestiona usuarios.', 403); }
}
function preserve_admin(array $target, string $role, int $active): void {
    if ($target['rol'] === 'administrador' && (int)$target['activo'] === 1 && ($role !== 'administrador' || !$active)) {
        $n = query("SELECT COUNT(*) FROM usuarios WHERE rol='administrador' AND activo=1")->fetchColumn();
        if ((int)$n <= 1) { db()->rollBack(); fail('Debe quedar al menos un administrador activo. Puedes editar su nombre, correo y contraseña.'); }
    }
}
function catalogue(bool $answers = true): array {
    $modules=[]; $questions=[]; $cases=[];
    foreach (query('SELECT * FROM modulos ORDER BY orden, id')->fetchAll() as $m) {
        $modules[]=['id'=>(int)$m['id'],'title'=>$m['titulo'],'subtitle'=>$m['subtitulo'],'color'=>$m['color'],'icon'=>$m['icono'],'time'=>$m['duracion'],'activity'=>$m['actividad'],'lessons'=>json_decode($m['lecciones'],true,512,JSON_THROW_ON_ERROR)];
    }
    foreach (query('SELECT * FROM preguntas ORDER BY modulo_id, id')->fetchAll() as $q) {
        $item=['id'=>$q['id'],'module'=>(int)$q['modulo_id'],'prompt'=>$q['enunciado'],'options'=>json_decode($q['opciones'],true,512,JSON_THROW_ON_ERROR)];
        if ($answers) { $item['answer']=(int)$q['respuesta']; $item['explanation']=$q['explicacion']; } $questions[]=$item;
    }
    foreach (query('SELECT * FROM casos ORDER BY modulo_id, id')->fetchAll() as $c) {
        $item=['id'=>$c['id'],'module'=>(int)$c['modulo_id'],'title'=>$c['titulo'],'story'=>$c['escenario'],'category'=>$c['categoria'],'clues'=>json_decode($c['pistas'],true,512,JSON_THROW_ON_ERROR),'options'=>json_decode($c['opciones'],true,512,JSON_THROW_ON_ERROR)];
        if ($answers) { $item['answer']=(int)$c['respuesta']; $item['explanation']=$c['explicacion']; } $cases[]=$item;
    }
    return ['modules'=>$modules,'questions'=>$questions,'cases'=>$cases];
}
function activity(int $id): array {
    $a=query('SELECT * FROM actividades WHERE modulo_id=?',[$id])->fetch(); if (!$a) fail('Actividad no encontrada.',404);
    return ['items'=>json_decode($a['elementos'],true),'targets'=>json_decode($a['destinos'],true),'correct'=>json_decode($a['orden_correcto'],true),'explanation'=>$a['explicacion']];
}
