<?php
header('X-Content-Type-Options: nosniff');
header('Referrer-Policy: same-origin');
header('X-Frame-Options: SAMEORIGIN');
header('Cache-Control: no-store');
?>
<!doctype html>
<html lang="es"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="description" content="Investiga, aprende y resuelve. Plataforma educativa de informática."><title>Detective Informático</title><link rel="icon" href="assets/favicon.svg"><link rel="stylesheet" href="assets/app.css"></head><body><div id="root"></div><script type="module" src="assets/app.js"></script><noscript>Activa JavaScript en tu navegador para utilizar las actividades de Detective Informático.</noscript></body></html>
