<?php
// Configuración local de XAMPP. phpMyAdmin es la herramienta para importar el SQL.
return [
    'host' => getenv('DETECTIVE_DB_HOST') ?: '127.0.0.1',
    'port' => getenv('DETECTIVE_DB_PORT') ?: '3306',
    'database' => getenv('DETECTIVE_DB_NAME') ?: 'detective_informatico',
    'username' => getenv('DETECTIVE_DB_USER') ?: 'root',
    'password' => getenv('DETECTIVE_DB_PASSWORD') ?: '',
    'session_minutes' => 120,
    'timezone' => 'America/Panama',
];
