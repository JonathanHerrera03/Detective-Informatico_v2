import assert from 'node:assert/strict';
const base=process.env.DETECTIVE_QA_URL||'http://127.0.0.1:8089/detective-informatico/';
assert.ok(['127.0.0.1','localhost'].includes(new URL(base).hostname),'Solo se permiten pruebas locales.');
assert.equal(process.env.DETECTIVE_QA_ALLOW_SETUP,'1','Usa una base de pruebas vacía y define DETECTIVE_QA_ALLOW_SETUP=1.');
class Client {
 cookies=new Map();csrf='';
 async request(body){const headers={};if(this.cookies.size)headers.Cookie=Array.from(this.cookies,([k,v])=>k+'='+v).join('; ');if(body){headers['Content-Type']='application/json';headers['X-CSRF-Token']=this.csrf;headers.Origin=new URL(base).origin;}
 const r=await fetch(new URL('api/academia.php',base),{method:body?'POST':'GET',headers,body:body?JSON.stringify(body):undefined});for(const c of r.headers.getSetCookie()){const pair=c.split(';')[0],i=pair.indexOf('=');this.cookies.set(pair.slice(0,i),pair.slice(i+1));}const raw=await r.text();let data;try{data=JSON.parse(raw)}catch{throw Error('Respuesta no JSON: '+raw.slice(0,400))}if(data.csrf)this.csrf=data.csrf;return {status:r.status,data};}
 async state(){const r=await this.request();assert.equal(r.status,200,JSON.stringify(r.data));return r.data;}
 async post(body,status=200){const r=await this.request(body);assert.equal(r.status,status,JSON.stringify(r.data));if(status===200&&['setup','register','login','logout','password'].includes(body.action))await this.state();return r.data;}
}
const admin=new Client(),student=new Client(),teacher=new Client(),second=new Client();
const first=await admin.state();assert.equal(first.setupRequired,true,'La base de pruebas debe carecer de administrador con contraseña.');assert.equal(first.user,null);assert.deepEqual(first.catalogue,{modules:[],questions:[],cases:[]});assert.deepEqual(first.activities,{});assert.deepEqual(first.games,{});assert.deepEqual(first.attempts,[]);assert.deepEqual(first.users,[]);assert.deepEqual(first.assignments,[]);
await admin.post({action:'attempt',kind:'quiz',module:1,answers:{}},401);
await admin.post({action:'setup',name:'QA Administrador',email:'admin.qa@example.test',password:'Pruebas-locales-2026!'});
let state=await admin.state(),adminId=state.user.id;assert.equal(state.user.role,'administrador');assert.equal(state.setupRequired,false);assert.equal(state.catalogue.modules.length,6);assert.equal(state.catalogue.modules.reduce((n,m)=>n+m.lessons.length,0),31);assert.equal(state.catalogue.questions.length,21);assert.equal(state.catalogue.cases.length,6);assert.equal(Object.keys(state.activities).length,6);
await admin.post({action:'setup',name:'Otro',email:'otro@example.test',password:'Pruebas-locales-2026!'},400);
await student.state();
await student.post({action:'register',name:'Acceso no permitido',email:'intruso.qa@example.test',password:'Pruebas-locales-2026!',role:'administrador'},403);
await student.post({action:'register',name:'Rol no válido',email:'rol.qa@example.test',password:'Pruebas-locales-2026!',role:'superadmin'},400);
await student.post({action:'register',name:'Rol no válido',email:'rol.qa@example.test',password:'Pruebas-locales-2026!',role:{name:'administrador'}},400);
assert.equal((await admin.state()).users.length,1);
await student.post({action:'register',name:'QA Estudiante',email:'student.qa@example.test',password:'Pruebas-locales-2026!',role:'estudiante'});let learner=await student.state();const studentId=learner.user.id;assert.equal(learner.user.role,'estudiante');assert.equal(learner.users.length,0);assert.ok(!JSON.stringify(learner).includes('contrasena_hash'));assert.equal(learner.catalogue.modules.length,6);assert.ok(!('answer' in learner.catalogue.questions[0]));assert.equal(learner.activities[1].items.length,4);assert.ok(!('correct' in learner.activities[1]));
assert.deepEqual(Object.keys(learner.games),learner.catalogue.modules.map(m=>String(m.id)));assert.ok(Object.values(learner.games).every(game=>game.instructions.length>=3));
await teacher.state();await teacher.post({action:'register',name:'QA Docente',email:'teacher.qa@example.test',password:'Pruebas-locales-2026!',role:'docente'});const teacherId=(await teacher.state()).user.id;
assert.equal((await teacher.state()).user.role,'docente');
await student.post({action:'createAdmin',name:'Sin permiso',email:'prohibido.qa@example.test',password:'Pruebas-locales-2026!'},403);
await teacher.post({action:'createAdmin',name:'Sin permiso',email:'prohibido.qa@example.test',password:'Pruebas-locales-2026!'},403);
const anonymous=new Client();await anonymous.state();await anonymous.post({action:'createAdmin',name:'Sin sesión',email:'prohibido.qa@example.test',password:'Pruebas-locales-2026!'},401);
await admin.post({action:'createAdmin',name:'Correo repetido',email:'student.qa@example.test',password:'Pruebas-locales-2026!'},409);
await admin.post({action:'createAdmin',name:'Clave corta',email:'admin2.qa@example.test',password:'corta'},400);
await student.post({action:'user',id:teacherId,role:'administrador',active:1},403);await teacher.post({action:'user',id:adminId,role:'estudiante',active:1},403);
await student.post({action:'resource',type:'question',module:1,data:{}},403);await teacher.post({action:'resource',type:'module',module:1,data:{}},403);
await admin.post({action:'user',id:adminId,name:'Administrador editado',email:'admin.editado@example.test',role:'administrador',active:1});assert.equal((await admin.state()).user.name,'Administrador editado');await admin.post({action:'user',id:adminId,role:'estudiante',active:1},400);await admin.post({action:'user',id:adminId,role:'administrador',active:0},400);
await student.post({action:'attempt',kind:'quiz',module:6,answers:{}},400);await student.post({action:'attempt',kind:'quiz',module:1,answers:{}},400);
const catalogue=(await admin.state()).catalogue;
const wrong=Object.fromEntries(catalogue.questions.filter(q=>q.module===1).map(q=>[q.id,(q.answer+1)%4]));const graded=await student.post({action:'attempt',kind:'quiz',module:1,answers:wrong,score:999,points:9999});assert.equal(graded.score,0);assert.equal(graded.points,0);
for(const m of catalogue.modules){const answers=Object.fromEntries(catalogue.questions.filter(q=>q.module===m.id).map(q=>[q.id,q.answer]));const r=await student.post({action:'attempt',kind:'quiz',module:m.id,answers});assert.equal(r.score,r.total);assert.equal(r.points,150);}
await student.post({action:'attempt',kind:'activity',module:1,order:[0,0,0,0]},400);
for(const m of catalogue.modules){const r=await student.post({action:'attempt',kind:'activity',module:m.id,order:[0,1,2,3]});assert.equal(r.score,4);assert.equal(r.points,80);}
const correctExtras={1:[[1,0,2],[2,0,1]],2:[[0,1,2],[1,2,0]],3:[[1,2,0],[1,0,2]],4:[[0,0,1],[1,0,2]],5:[[1,0,2],[1,0,2]],6:[[1,0,2],[0,1,2]]};
const beforeExtras=await student.state();
for(const m of catalogue.modules){
 const extras=beforeExtras.activities[m.id].extras;
 assert.equal(extras.length,2);
 for(const [i,a] of extras.entries()){
  assert.equal(a.id,`activity-${m.id}-${i+2}`);
  assert.equal(a.questions.length,3);
  assert.ok(a.questions.every(q=>!('answer' in q)&&!('explanation' in q)));
  const r=await student.post({action:'attempt',kind:'activity',module:m.id,itemId:a.id,answers:correctExtras[m.id][i]});
  assert.equal(r.itemId,a.id);assert.equal(r.score,3);assert.equal(r.total,3);assert.equal(r.points,80);
 }
}
await student.post({action:'attempt',kind:'activity',module:1,itemId:'activity-2-2',answers:[0,1,2]},404);
await student.post({action:'attempt',kind:'activity',module:1,itemId:'activity-1-2',answers:[1,0]},400);
await student.post({action:'attempt',kind:'activity',module:1,itemId:'activity-1-2',answers:[1,'0',2]},400);
const partial=await student.post({action:'attempt',kind:'activity',module:1,itemId:'activity-1-2',answers:[0,0,2]});
assert.equal(partial.score,2);assert.equal(partial.feedback[0].correct,false);
assert.equal(new Set((await student.state()).attempts.filter(a=>a.kind==='activity').map(a=>a.item_id)).size,18);

for(const c of catalogue.cases){const r=await student.post({action:'attempt',kind:'case',module:c.module,itemId:c.id,answer:c.answer});assert.equal(r.score,1);assert.equal(r.points,100);}
learner=await student.state();assert.equal(learner.attempts.length,32);assert.ok(learner.attempts.every(a=>a.user_id===studentId));assert.ok((await teacher.state()).attempts.some(a=>a.user_id===studentId));
await teacher.post({action:'assign',studentId,module:2});assert.equal((await student.state()).assignments.length,1);
const q={module:1,prompt:'Pregunta de prueba',options:['A','B','C','D'],answer:2,explanation:'C es la correcta.'};await teacher.post({action:'resource',id:'qa-pregunta',type:'question',module:1,data:q});assert.ok((await teacher.state()).catalogue.questions.some(q=>q.id==='qa-pregunta'));q.prompt='Pregunta editada';await teacher.post({action:'resource',id:'qa-pregunta',type:'question',module:1,data:q});assert.equal((await teacher.state()).catalogue.questions.find(q=>q.id==='qa-pregunta').prompt,q.prompt);await teacher.post({action:'resource',id:'qa-pregunta',type:'question',module:1,data:{deleted:true}});
const c={...catalogue.cases[0],title:'Caso de prueba'};await teacher.post({action:'resource',id:'qa-caso',type:'case',module:1,data:c});assert.ok((await teacher.state()).catalogue.cases.some(c=>c.id==='qa-caso'));await teacher.post({action:'resource',id:'qa-caso',type:'case',module:1,data:{deleted:true}});
const m={...catalogue.modules[0],title:'Módulo de prueba'};await admin.post({action:'resource',type:'module',module:1,data:m});assert.equal((await student.state()).catalogue.modules[0].title,m.title);await admin.post({action:'resource',type:'module',module:1,data:catalogue.modules[0]});
await admin.post({action:'settings',title:'Laboratorio QA'});assert.equal((await admin.state()).lab,'Laboratorio QA');
await admin.post({action:'user',id:studentId,role:'estudiante',active:0});assert.equal((await student.state()).user,null);await student.post({action:'profile',name:'Bloqueado'},401);await admin.post({action:'user',id:studentId,role:'estudiante',active:1});
await student.post({action:'login',email:'student.qa@example.test',password:'Pruebas-locales-2026!'});
const extra=new Client();await extra.state();await extra.post({action:'login',email:'student.qa@example.test',password:'Pruebas-locales-2026!'});
await student.post({action:'password',currentPassword:'incorrecta',password:'Clave-nueva-2026!'},400);await student.post({action:'password',currentPassword:'Pruebas-locales-2026!',password:'Clave-nueva-2026!'});assert.equal((await extra.state()).user,null);
await admin.post({action:'user',id:studentId,password:'Restablecida-2026!',role:'estudiante',active:1});assert.equal((await student.state()).user,null);await student.post({action:'login',email:'student.qa@example.test',password:'Restablecida-2026!'});assert.equal((await student.state()).attempts.length,32);
const createdAdmin=await admin.post({action:'createAdmin',name:'QA Administrador dos',email:'admin2.qa@example.test',password:'Pruebas-locales-2026!'});
assert.equal((await admin.state()).user.id,adminId,'Crear otra cuenta no sustituye la sesión del administrador.');
await second.state();await second.post({action:'login',email:'admin2.qa@example.test',password:'Pruebas-locales-2026!'});const secondId=(await second.state()).user.id;
assert.equal(secondId,createdAdmin.id);assert.equal((await second.state()).user.role,'administrador');await admin.post({action:'user',id:secondId,name:'Otro administrador editado',email:'admin2.editado@example.test',role:'administrador',active:1});assert.equal((await second.state()).user.name,'Otro administrador editado');
await admin.post({action:'user',id:adminId,role:'docente',active:1});await admin.post({action:'user',id:secondId,role:'estudiante',active:1},403);await second.post({action:'user',id:adminId,role:'administrador',active:1});await admin.post({action:'user',id:secondId,role:'estudiante',active:1});await admin.post({action:'deleteUser',id:adminId},400);
const attack=await fetch(new URL('api/academia.php',base),{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({action:'logout'})});assert.equal(attack.status,403);
for(const p of ['database/detective_informatico.sql','database/datos_existentes.sql','config/config.php','frontend/src/academy.tsx','api/juegos.json','tests/comprobar.mjs'])assert.equal((await fetch(new URL(p,base))).status,403,'Archivo privado: '+p);
assert.equal((await fetch(new URL('assets/app.js',base))).status,200);assert.equal((await fetch(new URL('assets/app.css',base))).status,200);
await student.post({action:'logout'});const signedOut=await student.state();assert.equal(signedOut.user,null);assert.deepEqual(signedOut.catalogue,{modules:[],questions:[],cases:[]});assert.deepEqual(signedOut.activities,{});assert.deepEqual(signedOut.games,{});assert.deepEqual(signedOut.attempts,[]);assert.deepEqual(signedOut.users,[]);assert.deepEqual(signedOut.assignments,[]);assert.equal(signedOut.lab,'');await student.post({action:'attempt',kind:'quiz',module:1,answers:{}},401);await student.post({action:'login',email:'student.qa@example.test',password:'incorrecta'},401);
console.log('PASS: Portada sin contenido privado antes de iniciar sesión y después de salir. Apache + PHP + MySQL. Instalación, registro de estudiantes y profesores, creación exclusiva de administradores, sesión, CSRF, permisos, administradores, 6 evaluaciones, 18 actividades, 6 juegos con instrucciones, 6 casos, persistencia, edición, asignaciones, contraseñas y protección de archivos.');

if(process.env.DETECTIVE_QA_VISUAL==='1'){
 const visual=new Client();
 await visual.state();
 await visual.post({action:'register',name:'Alex Rivera',email:'visual.qa@example.test',password:'Pruebas-locales-2026!',role:'estudiante'});
 await visual.post({action:'attempt',kind:'quiz',module:1,answers:Object.fromEntries(catalogue.questions.filter(q=>q.module===1).map(q=>[q.id,q.answer]))});
 await visual.post({action:'attempt',kind:'activity',module:1,order:[0,1,2,3]});
 await visual.post({action:'attempt',kind:'activity',module:1,itemId:'activity-1-2',answers:[1,0,2]});
}
