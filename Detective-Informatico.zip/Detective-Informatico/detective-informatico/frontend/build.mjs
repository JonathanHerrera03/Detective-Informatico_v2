import {build} from 'esbuild';
await build({entryPoints:['src/main.tsx'],bundle:true,outfile:'../assets/app.js',minify:true,jsx:'automatic',target:['es2020'],legalComments:'linked',define:{'process.env.NODE_ENV':'"production"'}});
