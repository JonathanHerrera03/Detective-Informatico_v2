import {useCallback,useEffect,useRef,useState} from 'react';
import {Headphones,Pause,Play,Square,Volume2} from 'lucide-react';

function screenArea(){return document.querySelector<HTMLElement>('.modal[role="dialog"]')||document.querySelector<HTMLElement>('#main-content, #bienvenida');}
function screenText(){return screenArea()?.innerText.replace(/\s+/g,' ').trim().slice(0,14000)||'Estás en Detective Informático.';}

export function useNarrator(context:string,announcement:string){
 const supported=typeof window!=='undefined'&&'speechSynthesis' in window&&'SpeechSynthesisUtterance' in window;
 const [enabled,setEnabled]=useState(false),[reading,setReading]=useState(false),[paused,setPaused]=useState(false),[message,setMessage]=useState('');
 const generation=useRef(0),utterance=useRef<SpeechSynthesisUtterance|null>(null),pausedRef=useRef(false);
 const stop=useCallback(()=>{generation.current++;if(supported)window.speechSynthesis.cancel();utterance.current=null;pausedRef.current=false;setReading(false);setPaused(false);},[supported]);
 const say=useCallback((text:string)=>{
  if(!supported){setMessage('Este navegador no ofrece lectura en voz alta. Puedes usar el lector de pantalla del dispositivo.');return;}
  stop();
  const engine=window.speechSynthesis;
  const voices=engine.getVoices().filter(v=>v.localService&&/^es(?:-|_|$)/i.test(v.lang));
  const voice=voices.find(v=>v.lang.toLowerCase()==='es-pa')||voices[0];
  if(!voice){setMessage('No se encontró una voz local en español. Instala una voz en español en tu dispositivo y vuelve a pulsar Leer pantalla.');return;}
  const chunks=text.match(/.{1,175}(?:\s|$)|\S{176,}/g)||[text];
  const id=generation.current;
  setMessage('');setReading(true);engine.resume();
  function next(i:number){
   if(id!==generation.current)return;
   if(i>=chunks.length){utterance.current=null;setReading(false);return;}
   const u=new SpeechSynthesisUtterance(chunks[i].trim());u.voice=voice;u.lang=voice.lang;u.rate=.95;utterance.current=u;
   u.onend=()=>next(i+1);
   u.onerror=()=>{if(id===generation.current){utterance.current=null;setReading(false);setMessage('No se pudo reproducir la voz. Intenta leer la pantalla de nuevo.');}};
   engine.speak(u);
  }
  next(0);
 },[stop,supported]);
 useEffect(()=>{if(supported)window.speechSynthesis.getVoices();return()=>{generation.current++;if(supported)window.speechSynthesis.cancel();};},[supported]);
 useEffect(()=>{if(!enabled)return;if(announcement){say(announcement);return;}const heading=screenArea()?.querySelector('h1,h2')?.textContent?.trim();if(heading)say(`${heading}. Pulsa Leer pantalla para escuchar el contenido.`);},[context,announcement]);
 useEffect(()=>{
  if(!enabled)return;
  const identify=(event:Event)=>{
   const el=event.target;
   if(!(el instanceof HTMLElement)||el.closest('[data-narrator]')||pausedRef.current)return;
   if(!el.matches('button,a[href],input,select,textarea,[role="tab"]'))return;
   const field=el instanceof HTMLInputElement||el instanceof HTMLSelectElement||el instanceof HTMLTextAreaElement?el:null;
   const labelledBy=el.getAttribute('aria-labelledby')?.split(/\s+/).map(id=>document.getElementById(id)?.textContent||'').join(' ');
   const label=el.getAttribute('aria-label')||labelledBy||field?.labels?.[0]?.innerText||el.innerText;
   const selected=el instanceof HTMLSelectElement?el.selectedOptions[0]?.textContent:'';
   const checked=el instanceof HTMLInputElement&&['radio','checkbox'].includes(el.type)&&el.checked?' Seleccionado.':'';
   if(label?.trim())say(`${label.trim().slice(0,400)}.${selected?` ${selected}.`:''}${checked}`);
  };
  document.addEventListener('focusin',identify);document.addEventListener('change',identify);
  return()=>{document.removeEventListener('focusin',identify);document.removeEventListener('change',identify);};
 },[enabled,say]);
 function toggle(){if(enabled){stop();setEnabled(false);setMessage('');}else{setEnabled(true);say('Narrador activado. Usa Tab para recorrer los controles. Pulsa Leer pantalla para escuchar el contenido, o Detener para interrumpir la lectura.');}}
 function togglePause(){if(!reading)return;const engine=window.speechSynthesis;if(paused){engine.resume();pausedRef.current=false;setPaused(false);}else{engine.pause();pausedRef.current=true;setPaused(true);}}
 return {enabled,reading,paused,message,toggle,togglePause,stop,read:()=>say(screenText()),announce:(text:string)=>{if(enabled&&!pausedRef.current)say(text);}};
}

export function NarratorControls({narrator,inline=false}:{narrator:ReturnType<typeof useNarrator>;inline?:boolean}){
 return <section id={inline?undefined:'narrator-control'} tabIndex={-1} className={`narrator-controls${inline?' narrator-inline':''}`} data-narrator aria-label="Ayuda de lectura en voz alta">
  <div className="narrator-actions"><button type="button" className="narrator-toggle" aria-pressed={narrator.enabled} onClick={narrator.toggle}><Headphones size={17} aria-hidden="true"/>{narrator.enabled?'Desactivar narrador':'Activar narrador'}</button>
  {narrator.enabled&&<><button type="button" onClick={narrator.read}><Volume2 size={16} aria-hidden="true"/>Leer pantalla</button><button type="button" disabled={!narrator.reading} onClick={narrator.togglePause}>{narrator.paused?<Play size={15} aria-hidden="true"/>:<Pause size={15} aria-hidden="true"/>}{narrator.paused?'Reanudar':'Pausar'}</button><button type="button" disabled={!narrator.reading} onClick={narrator.stop}><Square size={14} aria-hidden="true"/>Detener</button></>}
  </div>{narrator.message&&<p role="status">{narrator.message}</p>}
 </section>;
}
