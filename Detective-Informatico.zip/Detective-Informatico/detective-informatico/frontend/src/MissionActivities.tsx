import {useState} from 'react';
import type {ReactNode} from 'react';
import {Check,CheckCircle2,ClipboardList,GripVertical,Link2,ScanSearch,Sparkles,Star,Trophy} from 'lucide-react';

export type ExtraActivity={id:string;title:string;task:string;questions:{prompt:string;options:string[]}[]};
export type ModuleActivities={items:string[];targets:string[];extras?:ExtraActivity[]};
export type AttemptResult={itemId?:string;score:number;total:number;points:number;feedback:{id?:string;correct:boolean;answer?:number;explanation:string}[]};
type ActivityPayload={itemId:string;order?:number[];answers?:Record<string,number>};
type RecordResult={module_id:number;kind:string;item_id:string;score:number;total:number};

export function activityIds(moduleId:number,activities?:ModuleActivities){return [`activity-${moduleId}`,...(activities?.extras||[]).map(a=>a.id)];}
export function missionProgress(moduleId:number,activities:ModuleActivities|undefined,attempts:RecordResult[]){
 const mine=attempts.filter(a=>a.module_id===moduleId&&a.total>0);
 const perfect=(a:RecordResult)=>a.score===a.total;
 const ids=activityIds(moduleId,activities);
 const activitiesDone=ids.filter(id=>mine.some(a=>a.kind==='activity'&&a.item_id===id&&perfect(a))).length;
 const caseDone=mine.some(a=>a.kind==='case'&&perfect(a));
 const quizDone=mine.some(a=>a.kind==='quiz'&&a.score/a.total>=.7);
 return Math.round(100*(activitiesDone+Number(caseDone)+Number(quizDone))/(ids.length+2));
}

export function Celebration({kind,moduleTitle,points,complete}:{kind:string;moduleTitle:string;points:number;complete:boolean}){
 const label=kind==='case'?'Caso resuelto':kind==='activity'?'Actividad superada':'Evaluación aprobada';
 const Icon=complete?Trophy:kind==='case'?ScanSearch:Star;
 return <div className="mission-celebration" role="status"><div className="celebration-sparks" aria-hidden="true"><i/><i/><i/><i/><i/><i/><i/><i/></div><span className="celebration-medal" aria-hidden="true"><Icon size={30}/></span><div><span className="celebration-tag"><Sparkles size={14} aria-hidden="true"/>{label} · {points} XP</span><strong>{complete?'¡Módulo completado!':`¡${label}!`}</strong><p>{complete?`Has completado todos los retos de ${moduleTitle}. ¡Gran trabajo, detective!`:'Encontraste la solución. ¡Bien hecho, detective!'}</p></div></div>;
}

type PanelProps={moduleId:number;originalTitle:string;activities:ModuleActivities;active:number;locked:boolean;busy:boolean;feedback:AttemptResult|null;isDone:(id:string)=>boolean;onChoose:(index:number)=>void;onSubmit:(payload:ActivityPayload)=>void;children:ReactNode};
export function ActivityPanel({moduleId,originalTitle,activities,active,locked,busy,feedback,isDone,onChoose,onSubmit,children}:PanelProps){
 const ids=activityIds(moduleId,activities), extras=activities.extras||[], challenge=extras[active-1];
 const [choices,setChoices]=useState<Record<string,number>>({});
 const [order,setOrder]=useState<number[]>(()=>activities.items.map((_,i)=>(i+1)%activities.items.length));
 const [dragged,setDragged]=useState<number|null>(null);
 const titles=[originalTitle,...extras.map(a=>a.title)];
 const description=challenge?'Lee la situación y elige una respuesta en cada decisión.':'Relaciona cada concepto con su descripción. Puedes arrastrar las tarjetas o usar los selectores con el teclado.';
 function place(index:number,value:number){setOrder(previous=>{const next=[...previous],old=next.indexOf(value);if(old<0)return previous;[next[index],next[old]]=[next[old],next[index]];return next;});}
 return <section className="panel activity-panel mission-activities" aria-labelledby="mission-activity-title">
  <header className="mission-activities-head"><span className="pill lavender"><ClipboardList size={15} aria-hidden="true"/>LABORATORIO DE RETOS</span><h2 id="mission-activity-title">Actividades del módulo</h2><p>Completa los {titles.length} retos. Cada uno suma hasta 80 XP.</p></header>
  <nav className="challenge-picker" aria-label="Actividades del módulo">{titles.map((title,i)=>{const Icon=i===0?Link2:i===1?ScanSearch:ClipboardList;const done=isDone(ids[i]);return <button key={ids[i]} type="button" className={`challenge-choice${i===active?' chosen':''}`} aria-pressed={i===active} disabled={busy} onClick={()=>onChoose(i)}><span className="challenge-icon"><Icon size={22} aria-hidden="true"/></span><span><small>Actividad {i+1}</small><strong>{title}</strong></span>{done&&<span className="challenge-done" aria-label="Completada"><CheckCircle2 size={17} aria-hidden="true"/></span>}</button>;})}</nav>
  {locked?<div className="locked"><h3>La misión final todavía está bloqueada</h3><p>Aprueba las evaluaciones de los módulos 1 al 5 para desbloquearla.</p></div>:<>
  <div className="challenge-intro"><span className="eyebrow">ACTIVIDAD {active+1} DE {titles.length} · 80 XP</span><h3>{titles[active]}</h3>{challenge&&<p>{challenge.task}</p>}<p>{description}</p></div>
  {challenge?<div className="quiz-questions challenge-questions">{challenge.questions.map((q,i)=>{const result=feedback?.feedback.find(f=>f.id===String(i));return <fieldset key={i}><legend><span>{String(i+1).padStart(2,'0')}</span>{q.prompt}</legend><div className="options-grid">{q.options.map((option,n)=><label key={n} className={`option${choices[i]===n?' chosen':''}${result?.answer===n?' correct':''}`}><input type="radio" name={`${challenge.id}-${i}`} value={n} checked={choices[i]===n} disabled={!!feedback||busy} onChange={()=>setChoices({...choices,[i]:n})}/><span className="option-letter" aria-hidden="true">{String.fromCharCode(65+n)}</span><span>{option}</span>{result?.answer===n&&<Check size={16} aria-hidden="true"/>}</label>)}</div>{result&&<p className={`inline-feedback ${result.correct?'correct-text':'incorrect-text'}`}>{result.correct?'Correcto. ':'Para revisar. '}{result.explanation}</p>}</fieldset>;})}</div>:<div className="matching-grid"><div className="matching-bank"><span className="eyebrow">TUS PISTAS</span>{activities.items.map((item,n)=><div key={n} draggable={!feedback&&!busy} onDragStart={()=>setDragged(n)} onDragEnd={()=>setDragged(null)} className="drag-card"><GripVertical size={17} aria-hidden="true"/>{item}</div>)}</div><div className="matching-targets"><span className="eyebrow">CONECTA LAS RESPUESTAS</span>{activities.targets.map((target,i)=><div key={i} className="drop-zone" onDragOver={e=>{if(!feedback&&!busy)e.preventDefault();}} onDrop={e=>{e.preventDefault();if(dragged!==null&&!feedback&&!busy)place(i,dragged);}}><label htmlFor={`relation-${moduleId}-${i}`}><strong>{target}</strong></label><select id={`relation-${moduleId}-${i}`} value={order[i]} disabled={!!feedback||busy} onChange={e=>place(i,Number(e.target.value))}>{activities.items.map((item,n)=><option key={n} value={n}>{item}</option>)}</select>{feedback&&<span className={feedback.feedback[i]?.correct?'correct-text':'incorrect-text'}>{feedback.feedback[i]?.correct?'✓ Correcto':'Revisa esta relación'}</span>}</div>)}</div></div>}
  {!feedback&&<><button className="btn primary" disabled={busy||(!!challenge&&Object.keys(choices).length!==challenge.questions.length)} onClick={()=>onSubmit(challenge?{itemId:challenge.id,answers:choices}:{itemId:ids[0],order})}>Comprobar actividad<Check size={16} aria-hidden="true"/></button>{challenge&&Object.keys(choices).length!==challenge.questions.length&&<p className="challenge-hint">Responde las {challenge.questions.length} decisiones para comprobar.</p>}</>}
  {children}</>}
 </section>;
}
