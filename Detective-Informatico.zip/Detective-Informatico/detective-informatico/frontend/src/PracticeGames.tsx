import {useEffect,useRef,useState} from 'react';
import {ArrowDown,ArrowLeft,ArrowRight,ArrowUp,Check,ClipboardList,Cpu,Gamepad2,Layers,LockKeyhole,Mail,Network,Play,RotateCcw,Search,Sparkles,Trophy,X} from 'lucide-react';

type Piece={id:string;label:string};
type Node=Piece&{row:number;col:number};
type Common={title:string;tag:string;intro:string;instructions:string[]};
type Assemble=Common&{kind:'assemble';slots:{label:string;part:string}[];parts:Piece[]};
type Route=Common&{kind:'route';start:string;goal:string;required:string;nodes:Node[];links:[string,string][]};
type Triage=Common&{kind:'triage';decisions:Piece[];messages:{from:string;subject:string;body:string;answer:string;feedback:string}[]};
type Sequence=Common&{kind:'sequence';blocks:Piece[];order:string[]};
type Evidence=Common&{kind:'evidence';clues:(Piece&{result:string})[];diagnoses:Piece[];answer:string;feedback:string};
type Memory=Common&{kind:'memory';pairs:{id:string;term:string;meaning:string}[]};
export type GameData=Assemble|Route|Triage|Sequence|Evidence|Memory;
type Result={score:number;total:number;detail:string};
type BoardProps<T>={game:T;announce:(message:string)=>void;finish:(result:Result)=>void};
const icons={assemble:Cpu,route:Network,triage:Mail,sequence:Layers,evidence:Search,memory:ClipboardList};
const labelOf=(items:Piece[],id:string)=>items.find(item=>item.id===id)?.label||'';

function shuffled<T,>(items:T[]){
 const copy=[...items];
 for(let i=copy.length-1;i>0;i--){const j=Math.floor(Math.random()*(i+1));[copy[i],copy[j]]=[copy[j],copy[i]];}
 return copy;
}

function AssembleBoard({game,announce,finish}:BoardProps<Assemble>){
 const [slots,setSlots]=useState<(string|null)[]>(()=>game.slots.map(()=>null));
 const [active,setActive]=useState(0);
 function install(part:Piece){
  const next=[...slots];next[active]=part.id;setSlots(next);
  announce(`${part.label} colocado en el espacio ${active+1}.`);
 }
 function check(){
  const score=game.slots.filter((slot,i)=>slot.part===slots[i]).length;
  finish({score,total:game.slots.length,detail:`Montaje correcto: ${game.slots.map(slot=>`${slot.label}: ${labelOf(game.parts,slot.part)}`).join('; ')}.`});
 }
 return <div className="game-split">
  <div className="game-board-block"><h3 tabIndex={-1} data-board-heading>Espacios de montaje</h3><div className="game-slots">{game.slots.map((slot,i)=><button key={slot.label} className="game-tile" aria-pressed={active===i} onClick={()=>{setActive(i);announce(`Espacio ${i+1}: ${slot.label}. Elige una pieza del inventario.`);}}><span className="game-number" aria-hidden="true">{i+1}</span><span><strong>{slot.label}</strong><small>{slots[i]?labelOf(game.parts,slots[i]!):'Sin pieza'}</small></span></button>)}</div></div>
  <div className="game-board-block"><h3>Inventario</h3><p>Coloca una pieza en el espacio {active+1}.</p><div className="game-inventory">{game.parts.map(part=><button key={part.id} className="game-piece" disabled={slots.some((id,i)=>i!==active&&id===part.id)} onClick={()=>install(part)}><Cpu size={17} aria-hidden="true"/>{part.label}</button>)}</div><button className="btn primary" disabled={slots.some(part=>part===null)} onClick={check}>Revisar montaje<Check size={16} aria-hidden="true"/></button></div>
 </div>;
}

function RouteBoard({game,announce,finish}:BoardProps<Route>){
 const [path,setPath]=useState([game.start]);
 const heading=useRef<HTMLHeadingElement>(null);
 const at=path[path.length-1];
 const next=game.links.flatMap(([a,b])=>a===at?[b]:b===at?[a]:[]).filter(id=>!path.includes(id));
 const filtered=path.includes(game.required);
 function move(node:Node){
  if(!next.includes(node.id))return;
  const newPath=[...path,node.id];setPath(newPath);
  if(node.id===game.goal){
   const safe=newPath.includes(game.required);
   finish({score:Number(safe),total:1,detail:safe?`Ruta segura: ${newPath.map(id=>labelOf(game.nodes,id)).join(' → ')}.`:'El paquete llegó, pero saltó el filtro. En el próximo intento toma la ruta superior pasando por el Filtro.'});
  }else{
   const neighbors=game.links.flatMap(([a,b])=>a===node.id?[b]:b===node.id?[a]:[]).filter(id=>!newPath.includes(id));
   heading.current?.focus({preventScroll:true});
   announce(`Paquete en ${node.label}. ${node.id===game.required?'Filtro superado. ':''}${neighbors.length?`Siguientes saltos: ${neighbors.map(id=>labelOf(game.nodes,id)).join(', ')}.`:'No quedan saltos nuevos; usa Retroceder.'}`);
  }
 }
 return <div className="game-board-block game-route">
  <h3 ref={heading} tabIndex={-1} data-board-heading>Mapa de conexiones</h3><p>Paquete en: <strong>{labelOf(game.nodes,at)}</strong> · {filtered?'Filtro superado':'Filtro pendiente'}</p>
  <div className="game-map" aria-label="Nodos de la red">
   <svg viewBox="0 0 300 300" preserveAspectRatio="none" aria-hidden="true">{game.links.map(([from,to])=>{const a=game.nodes.find(n=>n.id===from)!,b=game.nodes.find(n=>n.id===to)!;return <line key={`${from}-${to}`} className={path.some((id,i)=>i>0&&(id===to&&path[i-1]===from||id===from&&path[i-1]===to))?'visited':''} x1={a.col*100-50} y1={a.row*100-50} x2={b.col*100-50} y2={b.row*100-50}/>;})}</svg>
   {game.nodes.map(node=><button key={node.id} className="game-node" style={{gridColumn:node.col,gridRow:node.row}} data-state={node.id===at?'current':path.includes(node.id)?'visited':next.includes(node.id)?'next':'idle'} disabled={!next.includes(node.id)} aria-label={`${node.label}${node.id===at?', posición actual':next.includes(node.id)?', siguiente salto disponible':''}`} onClick={()=>move(node)}><Network size={18} aria-hidden="true"/>{node.label}</button>)}
  </div>
  <p>Ruta: {path.map(id=>labelOf(game.nodes,id)).join(' → ')}</p>
  <p>{next.length?`Siguientes saltos: ${next.map(id=>labelOf(game.nodes,id)).join(', ')}.`:'No quedan saltos nuevos; retrocede para probar otro camino.'}</p>
  <button className="btn secondary" disabled={path.length===1} onClick={()=>{const previous=path.slice(0,-1);setPath(previous);heading.current?.focus({preventScroll:true});announce(`Paquete de vuelta en ${labelOf(game.nodes,previous[previous.length-1])}.`);}}><ArrowLeft size={16} aria-hidden="true"/>Retroceder</button>
 </div>;
}

function TriageBoard({game,announce,finish}:BoardProps<Triage>){
 const [index,setIndex]=useState(0),[score,setScore]=useState(0),[choice,setChoice]=useState('');
 const message=game.messages[index];
 const heading=useRef<HTMLHeadingElement>(null);
 const feedback=useRef<HTMLParagraphElement>(null);
 function classify(id:string){
  if(choice)return;
  const correct=id===message.answer;setChoice(id);setScore(n=>n+Number(correct));
  announce(`${correct?'Clasificación correcta.':`La mejor acción era ${labelOf(game.decisions,message.answer)}.`} ${message.feedback}`);
  requestAnimationFrame(()=>feedback.current?.focus({preventScroll:true}));
 }
 function advance(){
  if(index+1===game.messages.length){finish({score,total:game.messages.length,detail:'Recuerda: verifica los mensajes inesperados por un canal conocido y reporta los que pidan claves o códigos privados.'});return;}
  const next=game.messages[index+1];setIndex(index+1);setChoice('');
  requestAnimationFrame(()=>heading.current?.focus({preventScroll:true}));
  announce(`Mensaje ${index+2}. ${next.subject}. De ${next.from}. ${next.body}`);
 }
 return <div className="game-board-block"><h3 ref={heading} tabIndex={-1} data-board-heading>Bandeja de entrada · mensaje {index+1} de {game.messages.length}</h3><article className="game-message"><span className="game-kicker">DE: {message.from}</span><h4>{message.subject}</h4><p>{message.body}</p></article><div className="game-inline">{game.decisions.map(item=><button className="btn secondary" key={item.id} disabled={!!choice} onClick={()=>classify(item.id)}>{item.label}</button>)}</div>{choice&&<div className="game-inline"><p ref={feedback} tabIndex={-1}>{choice===message.answer?'✓ Decisión acertada.':`La mejor acción era ${labelOf(game.decisions,message.answer)}.`}</p><button className="btn primary" onClick={advance}>{index+1===game.messages.length?'Ver resultado':'Siguiente mensaje'}<ArrowRight size={16} aria-hidden="true"/></button></div>}</div>;
}

function SequenceBoard({game,announce,finish}:BoardProps<Sequence>){
 const [available]=useState(()=>{const mixed=shuffled(game.blocks);return mixed.every((item,i)=>item.id===game.order[i])?[...mixed.slice(1),mixed[0]]:mixed;});
 const [order,setOrder]=useState<string[]>([]);
 function move(index:number,direction:number){
  const next=[...order],target=index+direction;if(target<0||target>=next.length)return;
  [next[index],next[target]]=[next[target],next[index]];setOrder(next);
  announce(`${labelOf(game.blocks,order[index])} Ahora está en el paso ${target+1}.`);
 }
 return <div className="game-split"><div className="game-board-block"><h3 tabIndex={-1} data-board-heading>Bloques disponibles</h3><div className="game-slots">{available.map(block=><button className="game-tile" key={block.id} disabled={order.includes(block.id)} onClick={()=>{setOrder([...order,block.id]);announce(`Paso ${order.length+1}: ${block.label}`);}}><Layers size={17} aria-hidden="true"/>{block.label}</button>)}</div></div><div className="game-board-block"><h3>Tu secuencia</h3>{!order.length&&<p>Añade el primer bloque para comenzar.</p>}<ol className="game-sequence">{order.map((id,i)=><li key={id}><span>{labelOf(game.blocks,id)}</span><div className="game-inline"><button className="game-mini" aria-label={`Subir paso ${i+1}: ${labelOf(game.blocks,id)}`} disabled={i===0} onClick={()=>move(i,-1)}><ArrowUp size={16} aria-hidden="true"/></button><button className="game-mini" aria-label={`Bajar paso ${i+1}: ${labelOf(game.blocks,id)}`} disabled={i===order.length-1} onClick={()=>move(i,1)}><ArrowDown size={16} aria-hidden="true"/></button><button className="game-mini" aria-label={`Quitar paso ${i+1}: ${labelOf(game.blocks,id)}`} onClick={()=>{setOrder(order.filter(value=>value!==id));announce('Bloque quitado de la secuencia.');}}><X size={16} aria-hidden="true"/></button></div></li>)}</ol><button className="btn primary" disabled={order.length!==game.blocks.length} onClick={()=>finish({score:order.filter((id,i)=>id===game.order[i]).length,total:game.blocks.length,detail:`Orden de ejecución: ${game.order.map((id,i)=>`${i+1}. ${labelOf(game.blocks,id)}`).join(' ')}`})}>Ejecutar secuencia<Play size={16} aria-hidden="true"/></button></div></div>;
}

function EvidenceBoard({game,announce,finish}:BoardProps<Evidence>){
 const [found,setFound]=useState<string[]>([]),[selected,setSelected]=useState('');
 return <div className="game-split"><div className="game-board-block"><h3 tabIndex={-1} data-board-heading>Pruebas del laboratorio</h3><div className="game-slots">{game.clues.map(clue=><div className="game-clue" key={clue.id}><button className="game-tile" aria-expanded={found.includes(clue.id)} aria-controls={`game-clue-${clue.id}`} onClick={()=>{if(found.includes(clue.id))setFound(found.filter(id=>id!==clue.id));else{setFound([...found,clue.id]);announce(clue.result);}}}><Search size={17} aria-hidden="true"/>{clue.label}</button><p id={`game-clue-${clue.id}`} hidden={!found.includes(clue.id)}>{clue.result}</p></div>)}</div></div><div className="game-board-block"><h3>Tu diagnóstico</h3><p>{found.length} de {game.clues.length} pruebas abiertas. Abre al menos dos para decidir.</p><fieldset className="game-diagnoses" disabled={found.length<2}><legend>Elige la causa de la falla</legend>{game.diagnoses.map(d=><label key={d.id}><input type="radio" name="game-diagnosis" value={d.id} checked={selected===d.id} onChange={()=>setSelected(d.id)}/>{d.label}</label>)}</fieldset><button className="btn primary" disabled={found.length<2||!selected} onClick={()=>finish({score:Number(selected===game.answer),total:1,detail:game.feedback})}>Cerrar investigación<Check size={16} aria-hidden="true"/></button></div></div>;
}

function MemoryBoard({game,announce,finish}:BoardProps<Memory>){
 const [deck]=useState(()=>shuffled(game.pairs.flatMap(pair=>[{key:`${pair.id}-term`,pair:pair.id,text:pair.term},{key:`${pair.id}-meaning`,pair:pair.id,text:pair.meaning}])));
 const [opened,setOpened]=useState<number[]>([]),[matched,setMatched]=useState<string[]>([]),[turns,setTurns]=useState(0);
 const heading=useRef<HTMLHeadingElement>(null);
 function flip(index:number){
  if(opened.length===2||opened.includes(index)||matched.includes(deck[index].pair))return;
  const card=deck[index];setOpened([...opened,index]);
  heading.current?.focus({preventScroll:true});
  if(opened.length===0){announce(`Ficha ${index+1}: ${card.text}. Elige otra ficha.`);return;}
  setTurns(turns+1);
  if(deck[opened[0]].pair===card.pair){
   const next=[...matched,card.pair];setMatched(next);
   if(next.length===game.pairs.length){finish({score:next.length,total:game.pairs.length,detail:`Encontraste todas las parejas en ${turns+1} turnos.`});return;}
   announce(`Ficha ${index+1}: ${card.text}. Pareja encontrada. ${next.length} de ${game.pairs.length}. Pulsa Siguiente turno.`);
  }else announce(`Ficha ${index+1}: ${card.text}. Las fichas no coinciden. Pulsa Siguiente turno.`);
 }
 return <div className="game-board-block"><h3 ref={heading} tabIndex={-1} data-board-heading>Tablero de evidencias</h3><p>{matched.length} de {game.pairs.length} parejas · {turns} {turns===1?'turno':'turnos'}</p><div className="game-memory">{deck.map((card,i)=>{const found=matched.includes(card.pair),visible=found||opened.includes(i);return <button className="game-memory-card" key={card.key} data-state={found?'matched':visible?'open':'closed'} disabled={found||visible||opened.length===2} aria-label={`Ficha ${i+1}${visible?`: ${card.text}${found?', pareja encontrada':''}`:', boca abajo'}`} onClick={()=>flip(i)}>{visible?<><small>{found?'Pareja encontrada':`Ficha ${i+1}`}</small>{card.text}</>:<><span aria-hidden="true">?</span>Ficha {i+1}</>}</button>;})}</div><button className="btn primary" disabled={opened.length!==2} onClick={()=>{setOpened([]);heading.current?.focus({preventScroll:true});announce('Nuevo turno. Elige dos fichas.');}}>Siguiente turno<ArrowRight size={16} aria-hidden="true"/></button></div>;
}

export default function PracticeGame({game,locked,onAnnounce}:{game:GameData;locked:boolean;onAnnounce:(text:string)=>void}){
 const [started,setStarted]=useState(false),[result,setResult]=useState<Result|null>(null),[status,setStatus]=useState(''),[round,setRound]=useState(0);
 const section=useRef<HTMLElement>(null);
 const Icon=icons[game.kind];
 const announce=(text:string)=>{setStatus(text);onAnnounce(text);};
 function begin(){setRound(n=>n+1);setResult(null);setStarted(true);announce(`Comenzó ${game.title}. ${game.instructions[0]}`);requestAnimationFrame(()=>section.current?.querySelector<HTMLElement>('[data-board-heading]')?.focus({preventScroll:true}));}
 function finish(value:Result){setResult(value);announce(`${value.score===value.total?'¡Juego superado!':'Ronda terminada.'} ${value.score} de ${value.total}. ${value.detail}`);}
 useEffect(()=>{if(result)section.current?.querySelector<HTMLElement>('[data-game-result]')?.focus();},[result]);
 const props={announce,finish};
 return <section ref={section} className="panel practice-game" aria-labelledby="game-title">
  <div className="game-banner"><span className="game-emblem"><Icon size={32} aria-hidden="true"/></span><div><span className="game-kicker"><Gamepad2 size={14} aria-hidden="true"/> JUEGO DEL MÓDULO · {game.tag}</span><h2 id="game-title">{game.title}</h2><p>{game.intro}</p></div></div>
  <details className="game-instructions" open={!started}><summary><ClipboardList size={17} aria-hidden="true"/> Instrucciones del juego</summary><ol>{game.instructions.map((step,i)=><li key={step}><span className="game-number" aria-hidden="true">{i+1}</span><span>{step}</span></li>)}</ol></details>
  <p className="game-practice-note">Modo práctica · Sin límite de tiempo · No modifica tus notas ni tus puntos</p>
  {locked?<div className="locked"><LockKeyhole size={22} aria-hidden="true"/><h3>El juego final aún está bloqueado</h3><p>Aprueba las evaluaciones de los primeros cinco módulos para desbloquearlo.</p></div>:!started?<button className="btn primary" onClick={begin}><Play size={17} aria-hidden="true"/>Jugar ahora</button>:result?<div className={`game-result${result.score===result.total?' won':''}`}><span className="game-medal" aria-hidden="true">{result.score===result.total?<Trophy size={28}/>:<Sparkles size={28}/>}</span><div><h3 data-game-result tabIndex={-1}>{result.score===result.total?'¡Juego superado!':'Ronda terminada'}</h3><strong>{result.score} de {result.total}</strong><p>{result.detail}</p><button className="btn primary" onClick={begin}><RotateCcw size={16} aria-hidden="true"/>Volver a jugar</button></div></div>:<div className="game-play" key={round}>
    {game.kind==='assemble'&&<AssembleBoard game={game} {...props}/>}
    {game.kind==='route'&&<RouteBoard game={game} {...props}/>}
    {game.kind==='triage'&&<TriageBoard game={game} {...props}/>}
    {game.kind==='sequence'&&<SequenceBoard game={game} {...props}/>}
    {game.kind==='evidence'&&<EvidenceBoard game={game} {...props}/>}
    {game.kind==='memory'&&<MemoryBoard game={game} {...props}/>}
    <button className="btn secondary game-restart" onClick={begin}><RotateCcw size={16} aria-hidden="true"/>Reiniciar juego</button>
  </div>}
  <p className="game-status" role="status" aria-atomic="true">{status}</p>
 </section>;
}
