import {createRoot} from 'react-dom/client';
import Academy from './academy';
import './globals.css';
import './readability.css';
import './mission-theme.css';
import './mission-extras.css';
import './practice-games.css';
createRoot(document.getElementById('root')!).render(<Academy/>);
